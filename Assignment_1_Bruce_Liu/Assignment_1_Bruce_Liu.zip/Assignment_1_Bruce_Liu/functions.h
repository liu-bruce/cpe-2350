#ifndef functions
#define functions

void float_and_double_range();
void problem7();
void test_conditional();


#endif
