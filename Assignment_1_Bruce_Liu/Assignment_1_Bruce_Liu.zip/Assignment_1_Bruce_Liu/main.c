#include <stdio.h>
#include "functions.h"
int main()
{

  problem7();

  return 0;
}
